#pragma once
#include "template.h"

class Material
{
};