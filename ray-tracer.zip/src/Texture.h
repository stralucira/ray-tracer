#pragma once

class Texture
{
};