﻿#include "template.h"
#include "Light.h"

Light::Light(vec3 pos, vec3 color)
{
	this->pos = pos;
	this->color = color;
}