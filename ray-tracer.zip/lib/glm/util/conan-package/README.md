Conan package for the [GLM](https://github.com/g-truc/glm) library

The package is hosted on [bintray](https://bintray.com/conan/conan-center?filterByPkgName=glm%3Ag-truc).

It works on Windows (Visual Studio or MinGW), MacOS/OSX and Linux.
